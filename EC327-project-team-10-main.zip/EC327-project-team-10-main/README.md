Open the terminal

Compile Code: g++ main.cpp -o run -lsfml-graphics -lsfml-window -lsfml-system

Run the program: ./run
